<?php
session_start();
include "../consulSQL.php";
ini_set('date.timezone','America/Mexico_City');

$codigo=$_POST['codigo'];
$nombre_producto=$_POST['nombre_producto'];
$descripcion=$_POST['descripcion'];
$precio_compra=$_POST['precio_compra'];
$precio_venta=$_POST['precio_venta'];
$id_categoria=$_POST['id_categoria'];
$seccion=$_POST['seccion'];
$fecha_creacion=date('d-m-Y H:i:s',time());

$existencia=0;
$img=$codigo.".jpg";
$consul_producto=  ejecutarSQL::consultar("SELECT * FROM producto WHERE codigo='".$codigo."'");
$num=mysqli_num_rows($consul_producto);

if ($num>0) {
	header("Location: ../../home.php?modulo=inventario&alert=5");
}else{
if(!$_FILES['img']['name']==""){
if($_FILES['img']['type']=="image/jpeg" || $_FILES['img']['type']=="image/png"){

	if(move_uploaded_file($_FILES['img']['tmp_name'],"../../img/img_productos/".$img)){
       
if(consultasSQL::InsertSQL("producto", "codigo,nombre,descripcion_prod,precio_compra,precio_venta,id_categoria,imagen,fecha_creacion,seccion", "'$codigo','$nombre_producto','$descripcion','$precio_compra','$precio_venta','$id_categoria','$img','$fecha_creacion','$seccion'")){
header("Location: ../../home.php?modulo=inventario&alert=4");	

    }else{
    echo "<br><div class='alert alert-danger alert-dismissable'>
        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
        <div class='text-center'><h4>  <i class='fa-window-close-o'></i>Ha ocurrido un error.</h4></div>
        Error al insertar, por favor intente de nuevo.
        </div>";	
    }	
	}else{
	header("Location: ../../home.php?modulo=inventario&alert=7");	
	}
}else{
header("Location: ../../home.php?modulo=inventario&alert=8");
}	

}else{
	header("Location: ../../home.php?modulo=inventario&alert=6");
}
}
?>