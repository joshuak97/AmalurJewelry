<?php 
if($_SESSION['id_usuario']==""){
header("Location: index.php"); 
}
?>