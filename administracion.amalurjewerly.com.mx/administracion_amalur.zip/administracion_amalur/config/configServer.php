<?php
//Conexion a la base de datos.
$user="root";
$host="localhost";
$pass="";
$bdd="amalur";
$con=mysqli_connect($host,$user,$pass,$bdd);
?>
